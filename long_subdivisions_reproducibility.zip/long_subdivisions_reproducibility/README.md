# Maximal Independent Sets in Long Graph Subdivisions

Research draft dated 29 October 2026. Named author: Daniel A. Pyle.

## Contents

- `long_subdivisions_manuscript.pdf`: the typeset research draft.
- `long_subdivisions_manuscript.tex`: complete editable LaTeX source; references are embedded.
- `code/candidate/check_subdivisions.py`: first implementation, with direct enumeration, boundary contraction, weighted moments, spectral checks, and example/correction checks.
- `code/audit/`: separately written count, joint-law, and weighted implementations. Keep these three files together.
- `reference_results/`: reports from completed runs on 29 October 2026.
- `verify_all.py`: portable runner that checks all four suites against the reference reports.
- `build_pdf.sh`: ordinary LaTeX build, without shell escape.
- `LICENSE_MANUSCRIPT.txt`: manuscript license notice.
- `SHA256SUMS`: package file checksums.

## Reproduce the checks

Python 3.10 or later is required; no third-party Python packages or network access are needed.

```sh
python3 verify_all.py
```

The runner copies the code to a temporary directory, executes all four suites, and saves fresh reports and logs under `verification_results/`. A failed assertion, nonzero process status, or mismatch causes failure. Do not use `-O` or `-OO`; optimized mode is explicitly rejected.

Expected successful coverage:

| Suite | Checks |
| --- | --- |
| Candidate | 3,300 exact unweighted cases; 386 rational weighted evaluations; 152 exact first/second-moment comparisons; 150 numerical spectral comparisons; 16 example-count/correction comparisons |
| Audit counts | 2,352 uniform-length and 1,979 mixed-length exact comparisons; cycles C3 through C17; spectral kernels and universal error bounds |
| Audit joint laws | 228 exact complete original-vertex selection histograms; connected degree-matched tree examples |
| Audit weighted | 456 rational weighted evaluations; numerical spectral kernels for k = 0 through 15 at activities 1/2, 1, and 2 |

These families overlap, so their totals are not counts of distinct graphs. The candidate's directly enumerated expanded graphs have at most 15 vertices; boundary-only examples include much larger expanded graphs. Combinatorial counts and rational weighted/moment checks use exact arithmetic. Spectral identities, limiting probabilities, and remainder bounds use floating point and are numerical sanity checks, not proofs. Each suite retains its own documented tolerance. The wrapper compares floating report fields at relative and absolute tolerance 1e-10 and ignores run time; all integer report fields and exact count outputs must agree exactly.

For separate runs, invoke each `.py` file directly. The programs write JSON reports beside themselves. Their successful exit is part of the check; the audit JSON formats do not contain a separate PASS flag.

## Build the manuscript

Use a normally configured TeX Live or MiKTeX installation with pdfLaTeX and the standard packages listed in the source: Latin Modern, AMS math/theorems/fonts, geometry, booktabs, array, microtype, xcolor, and hyperref.

```sh
sh build_pdf.sh
```

The rebuilt file is `build/long_subdivisions_manuscript.pdf`. Three passes resolve references and PDF bookmarks. The supplied PDF was built with pdfTeX 1.40.26 / LaTeX 2024-11-01 and checked for undefined references, warnings, and overfull boxes; every one of its 12 rendered pages was visually inspected. Font outlines are embedded. PDF byte identity is not promised across TeX versions, fonts, or build timestamps; reproducibility here concerns the formulas, examples, and computational checks.

The execution environment had an incomplete TeX configuration (missing filename database, format, and consolidated font map). Its existing distribution files were used to generate workspace-local format/map files and enable compilation. No downloaded packages or external compilation service were used. Those environment-specific generated files are not needed on a normally configured TeX installation and are not included.

## Research status and provenance

The exact formulas, count error bound, original-vertex product law, equal-length correction, growing-graph counterexample, and fixed-base size law are proved in the manuscript. AI systems carried out derivation, computation, writing, and separate internal checks. These checks do not constitute independent human mathematical verification, formal proof-assistant verification, or peer review. No claim is made that the named author has personally verified every argument.

The methods, one-dimensional recurrences, and bulk fluctuation constants have prior literature and are credited. Priority remains provisional: the bounded literature comparison was not exhaustive, and the full text of Hu, Mansour, and Song (2017), DOI 10.1216/RMJ-2017-47-7-2219, was not inspected. Its theorem-level relationship remains unresolved. An unverified ORCID was omitted. The package has not been externally submitted or published as part of this preparation.

The manuscript is licensed CC BY 4.0. No separate software license is asserted for the accompanying scripts. See the license notice for the exact scope.
