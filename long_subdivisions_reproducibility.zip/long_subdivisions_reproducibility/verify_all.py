#!/usr/bin/env python3
"""Run the four supplied suites and compare their reports to recorded results."""
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SUITES = [
    ("candidate/check_subdivisions.py", "candidate/check_results.json", "candidate.json"),
    ("audit/check.py", "audit/results.json", "results.json"),
    ("audit/law_and_trees.py", "audit/law_and_trees.json", "law_and_trees.json"),
    ("audit/weighted.py", "audit/weighted.json", "weighted.json"),
]

def compare(actual, expected, where="report"):
    if isinstance(expected, dict):
        if set(actual) != set(expected):
            raise ValueError(f"{where}: differing report fields")
        for key in expected:
            if key != "seconds":
                compare(actual[key], expected[key], f"{where}.{key}")
    elif isinstance(expected, list):
        if len(actual) != len(expected):
            raise ValueError(f"{where}: differing list lengths")
        for i, (a, e) in enumerate(zip(actual, expected)):
            compare(a, e, f"{where}[{i}]")
    elif isinstance(expected, float):
        if not math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-10):
            raise ValueError(f"{where}: numerical mismatch {actual!r} != {expected!r}")
    elif actual != expected:
        raise ValueError(f"{where}: exact mismatch {actual!r} != {expected!r}")

def main():
    if not __debug__:
        raise SystemExit("Run without -O or -OO: assertions are essential to these suites.")
    if sys.version_info < (3, 10):
        raise SystemExit("Python 3.10 or later is required.")
    outputs = ROOT / "verification_results"
    outputs.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="long-subdivisions-") as tmp:
        working = Path(tmp)
        shutil.copytree(ROOT / "code", working / "code")
        for program, generated, reference in SUITES:
            completed = subprocess.run(
                [sys.executable, str(working / "code" / program)],
                cwd=working, text=True, capture_output=True,
            )
            (outputs / (reference + ".log")).write_text(
                completed.stdout + completed.stderr, encoding="utf-8"
            )
            if completed.returncode:
                raise RuntimeError(f"{program} failed; see verification_results/{reference}.log")
            actual_path = working / "code" / generated
            actual = json.loads(actual_path.read_text())
            expected = json.loads((ROOT / "reference_results" / reference).read_text())
            compare(actual, expected, program)
            shutil.copy2(actual_path, outputs / reference)
            print(f"PASS {program}", flush=True)
    print("All four suites passed and matched recorded reports. Timing ignored; integer and rational-check totals match exactly.")
    print("Floating report values are compared at relative/absolute tolerance 1e-10; the suites retain their own stated tolerances.")

if __name__ == "__main__":
    main()
