#!/bin/sh
# Compile with a normally configured TeX Live or MiKTeX installation.
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
mkdir -p build
for pass in 1 2 3; do
    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error \
        -output-directory=build long_subdivisions_manuscript.tex \
        > "build/pass${pass}.log" 2>&1 || {
            cat "build/pass${pass}.log"
            exit 1
        }
done
printf '%s\n' 'Built build/long_subdivisions_manuscript.pdf'
