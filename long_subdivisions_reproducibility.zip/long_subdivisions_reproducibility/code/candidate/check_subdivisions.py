"""Independent brute force and exact 3-state contraction checks. Python standard library only."""
from itertools import combinations, product
from fractions import Fraction
from math import prod
import argparse, json, time
from pathlib import Path

STATES=((0,0),(0,1),(1,0)); REV=(0,2,1)

class Jet2:
    """Exact value, first derivative, second derivative with respect to t at t=0."""
    def __init__(self, value=0, first=0, second=0):
        self.v, self.d, self.dd = map(Fraction,(value,first,second))
    @staticmethod
    def coerce(other):
        return other if isinstance(other,Jet2) else Jet2(other)
    def __add__(self,other):
        o=self.coerce(other)
        return Jet2(self.v+o.v,self.d+o.d,self.dd+o.dd)
    __radd__=__add__
    def __mul__(self,other):
        o=self.coerce(other)
        return Jet2(self.v*o.v,self.d*o.v+self.v*o.d,
                    self.dd*o.v+2*self.d*o.d+self.v*o.dd)
    __rmul__=__mul__
    def __pow__(self,power):
        if power<0:
            inverse=Jet2(1/self.v,-self.d/self.v**2,
                         (2*self.d**2-self.v*self.dd)/self.v**3)
            return inverse**(-power)
        out=Jet2(1)
        for _ in range(power):out=out*self
        return out
    def __bool__(self):return bool(self.v or self.d or self.dd)
    def tuple(self):return self.v,self.d,self.dd


def matmul(A,B):
    return [[sum(A[i][k]*B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def matpow(A,k):
    B=[[int(i==j) for j in range(3)] for i in range(3)]
    while k:
        if k&1:B=matmul(B,A)
        A=matmul(A,A);k//=2
    return B

def edge_kernel(k,z=1):
    # k internal vertices: initial adjacent pair -> final reversed adjacent pair.
    T=[[0,z,0],[0,0,1],[1,z,0]]
    P=matpow(T,k)
    return [[z**(STATES[p][1]-STATES[q][0])*P[p][REV[q]] for q in range(3)] for p in range(3)]

def contraction(n,edges,ks,z=1):
    if not isinstance(z,Jet2):z=Fraction(z)
    # Inclusion-exclusion per original vertex: selected, unselected/free, undominated.
    supports=((2,),(0,1),(0,)); vertex_weights=(z,1,-1)
    matrices=[]
    for k in ks:
        K=edge_kernel(k,z)
        matrices.append([[sum(K[p][q] for p in supports[a] for q in supports[b]) for b in range(3)] for a in range(3)])
    ans=0
    for s in product(range(3),repeat=n):
        term=prod(vertex_weights[t] for t in s)
        for (u,v),K in zip(edges,matrices):
            term*=K[s[u]][s[v]]
            if not term:break
        ans+=term
    return ans

def subdivide(n,edges,ks):
    out=[];N=n
    for (u,v),k in zip(edges,ks):
        chain=[u]+list(range(N,N+k))+[v];N+=k
        out.extend(zip(chain,chain[1:]))
    return N,out

def brute_poly(n,edges):
    adj=[0]*n
    for u,v in edges:adj[u]|=1<<v;adj[v]|=1<<u
    full=(1<<n)-1; counts={}
    for mask in range(1<<n):
        dom=mask;todo=mask;ok=True
        while todo:
            b=todo&-todo;v=b.bit_length()-1;todo-=b
            if adj[v]&mask:ok=False;break
            dom|=adj[v]
        if ok and dom==full:
            q=mask.bit_count();counts[q]=counts.get(q,0)+1
    return counts

def spectral(n,edges,ks):
    # Closed-form roots, used only for floating numerical verification.
    lam=((9+(69)**.5)/18)**(1/3)+((9-(69)**.5)/18)**(1/3)
    alpha=complex(-lam/2, (1/lam-lam*lam/4)**.5)
    roots=(lam,alpha,alpha.conjugate());ans=0j
    incident=[[] for _ in range(n)]
    for i,(u,v) in enumerate(edges):incident[u].append(i);incident[v].append(i)
    for colors in product(roots,repeat=len(edges)):
        val=prod(r**k/(2*r+3) for r,k in zip(colors,ks))
        for ii in incident:
            val*=prod(colors[i]**2 for i in ii)+prod(1+colors[i] for i in ii)-1
        ans+=val
    return ans

def run(output_path):
    if not __debug__:
        raise RuntimeError("Run without -O: assertions are part of this verification suite.")
    start=time.time();cases=0;weighted=0;spectral_cases=0;moment_cases=0;largest=0
    for n in range(6):
        possible=list(combinations(range(n),2))
        for mask in range(1<<len(possible)):
            edges=[e for i,e in enumerate(possible) if mask>>i&1]
            # Test all 1100 labelled base graphs of order <=5, at k=0 and k=1.
            for k in (0,1):
                ks=[k]*len(edges);N,EE=subdivide(n,edges,ks)
                p=brute_poly(N,EE);expected=sum(p.values());actual=contraction(n,edges,ks)
                assert actual==expected,(n,edges,ks,actual,p)
                cases+=1;largest=max(largest,N)
                if n<=4:
                    moment=Jet2.coerce(contraction(n,edges,ks,Jet2(1,1,1)))
                    target=tuple(sum(a*b**j for b,a in p.items()) for j in range(3))
                    assert moment.tuple()==target,(n,edges,ks,moment.tuple(),target)
                    moment_cases+=1
                    for z in (Fraction(1,2),Fraction(2)):
                        assert contraction(n,edges,ks,z)==sum(a*z**b for b,a in p.items())
                        weighted+=1
                    if len(edges)<=5:
                        val=spectral(n,edges,ks)
                        assert abs(val-expected)<1e-7,(n,edges,ks,val,expected)
                        spectral_cases+=1
            # Mixed lengths: deterministic assignment, cap subdivision order.
            ks=[(i+mask)%3 for i in range(len(edges))]
            N,EE=subdivide(n,edges,ks)
            if N<=15:
                p=brute_poly(N,EE)
                assert contraction(n,edges,ks)==sum(p.values())
                cases+=1;largest=max(largest,N)
                if mask%31==0:
                    for z in (Fraction(1,2),Fraction(2)):
                        assert contraction(n,edges,ks,z)==sum(a*z**b for b,a in p.items())
                        weighted+=1
    examples=check_examples()
    result={'status':'PASS','unweighted_graph_length_cases':cases,
            'weighted_evaluations':weighted,'spectral_evaluations':spectral_cases,
            'exact_moment_evaluations':moment_cases,
            'example_count_and_correction_cases':len(examples['rows'])*2,
            'maximum_subdivided_order_bruteforce':largest,
            'seconds':round(time.time()-start,3),'examples':examples}
    print(json.dumps(result,indent=2))
    if output_path:
        Path(output_path).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    return result


def check_examples():
    lam=((9+69**.5)/18)**(1/3)+((9-69**.5)/18)**(1/3)
    alpha=complex(-lam/2,(1/lam-lam*lam/4)**.5)
    roots=(lam,alpha,alpha.conjugate());D=2*lam+3;theta=lam**(-1.5)
    A=lambda d:lam**(2*d)+(1+lam)**d-1
    B=lambda d:alpha**2*lam**(2*d-2)+(1+alpha)*(1+lam)**(d-1)-1
    graphs=([(0,1),(1,2),(0,2),(0,3),(3,4)],
            [(0,1),(1,2),(2,3),(0,3),(0,4)])
    expected={0:(5,3),1:(15,17),2:(61,62),3:(257,257),5:(4305,4256),
              10:(4860145,4854641),15:(5492075335,5491512521),
              20:(6206148196031,6206108377807)}
    rows=[];constants=[]
    for edges in graphs:
        degrees=[sum(v in e for e in edges) for v in range(5)]
        C=prod(A(d) for d in degrees)/D**len(edges)
        H=D/(2*alpha+3)*sum(B(degrees[u])*B(degrees[v])/A(degrees[u])/A(degrees[v]) for u,v in edges)
        incident=[[i for i,e in enumerate(edges) if v in e] for v in range(5)]
        remainder_constant=0.0
        for labels in product(range(3),repeat=len(edges)):
            if sum(label!=0 for label in labels)<2:continue
            colors=[roots[i] for i in labels]
            coefficient=prod(1/(2*r+3) for r in colors)/C
            for ii in incident:
                coefficient*=prod(colors[i]**2 for i in ii)+prod(1+colors[i] for i in ii)-1
            remainder_constant+=abs(coefficient)
        constants.append((C,H,remainder_constant))
    assert abs(constants[0][1])<1e-12
    assert abs(constants[1][1])>0.04
    assert abs(constants[0][0]-constants[1][0])<1e-12
    for k,counts in expected.items():
        actual=[];residuals=[]
        for g,(edges,(C,H,remainder_constant)) in enumerate(zip(graphs,constants)):
            count=int(contraction(5,edges,[k]*5))
            assert count==counts[g],(k,g,count,counts[g])
            normalized=count/(C*lam**(5*k))
            residual=normalized-1-2*(H*(alpha/lam)**k).real
            assert abs(residual)<=remainder_constant*theta**(2*k)+1e-11,(k,g,residual)
            actual.append(count);residuals.append(residual)
        rows.append({'k':k,'triangle_tail':actual[0],'square_leaf':actual[1],
                     'ratio_A_B':actual[0]/actual[1],
                     'first_correction_residuals':residuals})
    return {'lambda':lam,'theta':theta,'C':constants[0][0],
            'H_A':[constants[0][1].real,constants[0][1].imag],
            'H_B':[constants[1][1].real,constants[1][1].imag],
            'remainder_bounds':[c[2] for c in constants],'rows':rows}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',default=str(Path(__file__).with_name('check_results.json')),
                        help='JSON report path; use an empty string for stdout only')
    args=parser.parse_args()
    run(args.output)
