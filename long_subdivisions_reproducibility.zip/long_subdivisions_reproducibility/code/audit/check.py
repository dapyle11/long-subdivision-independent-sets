#!/usr/bin/env python3
"""Independent brute-force audit of maximal independent sets of subdivisions.
Standard library only. Tensor count uses original-vertex inclusion/exclusion;
brute count enumerates independent sets on the actual expanded graph.
"""
if not __debug__:
    raise RuntimeError("Run this verification suite without -O or -OO: its exact checks use assertions.")

from itertools import combinations, product
from math import sqrt
from pathlib import Path
import json, time
OUT=Path(__file__).resolve().parent
T=((0,1,0),(0,0,1),(1,1,0))
REV=(0,2,1)
TYPES=((2,),(0,1),(0,)) # selected, unselected, forbidden-undominated event

def matmul(a,b):
    return tuple(tuple(sum(a[i][h]*b[h][j] for h in range(3)) for j in range(3)) for i in range(3))
def power(k):
    a=((1,0,0),(0,1,0),(0,0,1)); b=T
    while k:
        if k&1: a=matmul(a,b)
        b=matmul(b,b); k//=2
    return a

def expand(n, edges, ks):
    es=[]; nn=n
    for (u,v),k in zip(edges,ks):
        chain=[u]+list(range(nn,nn+k))+[v]; nn+=k
        es.extend(zip(chain,chain[1:]))
    return nn,es

def brute(n,edges):
    adj=[0]*n
    for u,v in edges:
        adj[u]|=1<<v; adj[v]|=1<<u
    allmask=(1<<n)-1
    def rec(todo,dominated):
        if not todo: return int(dominated==allmask)
        ubit=todo&-todo; u=ubit.bit_length()-1
        rest=todo^ubit
        # Every independent subset occurs in exactly one include/exclude branch.
        return rec(rest,dominated)+rec(rest&~adj[u],dominated|ubit|adj[u])
    return rec(allmask,0)

def tensor(n,edges,ks):
    factors={}
    for k in set(ks):
        p=power(k); ker=tuple(tuple(p[i][REV[j]] for j in range(3)) for i in range(3))
        factors[k]=tuple(tuple(sum(ker[i][j] for i in TYPES[a] for j in TYPES[b]) for b in range(3)) for a in range(3))
    ans=0
    for types in product(range(3),repeat=n):
        term=-1 if types.count(2)%2 else 1
        for (u,v),k in zip(edges,ks):
            term*=factors[k][types[u]][types[v]]
            if not term: break
        ans+=term
    return ans

def allgraphs(n):
    possible=list(combinations(range(n),2))
    for mask in range(1<<len(possible)):
        yield [e for i,e in enumerate(possible) if mask>>i&1]

lam=((9+sqrt(69))/18)**(1/3)+((9-sqrt(69))/18)**(1/3)
D=2*lam+3; theta=lam**(-1.5); B=2*D/sqrt(9-6*lam+4/lam)
def lead(n,edges,ks):
    ds=[0]*n
    for u,v in edges: ds[u]+=1; ds[v]+=1
    ans=lam**sum(ks)/D**len(edges)
    for d in ds: ans*=lam**(2*d)+lam**(3*d)-1
    return ans

def run():
    started=time.time(); counts={}; total=0
    for k,nmax in [(0,5),(1,5),(2,4),(3,4)]:
        count=0
        for n in range(nmax+1):
            for edges in allgraphs(n):
                ks=[k]*len(edges); nn,ee=expand(n,edges,ks)
                actual=brute(nn,ee); predicted=tensor(n,edges,ks)
                assert actual==predicted,(n,edges,k,actual,predicted)
                count+=1
        counts[str(k)]=count;total+=count
        print('verified k',k,'graphs',count,flush=True)
    # Each edge length varies independently, with isolates, endpoints and cycles.
    mixed=0
    for n in range(5):
        for edges in allgraphs(n):
            if len(edges)>4: continue
            for ks in product(range(3),repeat=len(edges)):
                nn,ee=expand(n,edges,ks)
                actual=brute(nn,ee); predicted=tensor(n,edges,ks)
                assert actual==predicted,(n,edges,ks,actual,predicted)
                mixed+=1
    P5=[(0,1),(1,2),(2,3),(3,4)]
    triangle_edge=[(0,1),(1,2),(0,2),(3,4)]
    examples=[]
    for k in [0,1,2,3,4,5,10,20,40]:
        a=tensor(5,P5,[k]*4); b=tensor(5,triangle_edge,[k]*4)
        leading=lead(5,P5,[k]*4)
        examples.append(dict(k=k,path5_count=a,triangle_plus_edge_count=b,ratio=a/b,leading=leading,
                             path_relative_error=a/leading-1,other_relative_error=b/leading-1,
                             universal_relative_bound=(1+B*theta**k)**4-1))
    # Independent power recurrence yields trace(T^N) for every C_N, N>=3.
    cycles=[]
    for N in range(3,18):
        edges=[(i,(i+1)%N) for i in range(N)]
        p=power(N); exact=sum(p[i][i] for i in range(3))
        actual=brute(N,edges)
        assert actual==exact,(N,actual,exact)
        cycles.append([N,actual])
    # Check spectral identity and universal edge bound for all entries.
    mu=complex(-lam/2,sqrt(4/lam-lam*lam)/2)
    max_numeric_error=0.0
    for k in range(31):
        p=power(k)
        for a in range(3):
            for b in range(3):
                exact=p[a][REV[b]]
                spectral=lam**(k+a+b)/D+2*(mu**(k+a+b)/(2*mu+3)).real
                max_numeric_error=max(max_numeric_error,abs(exact-spectral)/max(1,abs(exact)))
                relative=abs(exact/(lam**(k+a+b)/D)-1)
                assert relative<=B*theta**k+1e-12,(k,a,b,relative,B*theta**k)
    result=dict(lambda_=lam,D=D,theta=theta,B=B,uniform_graph_cases=counts,
                total_uniform_cases=total,mixed_subdivision_cases=mixed,
                cycle_checks=cycles,spectral_max_relative_numeric_error=max_numeric_error,
                degree_matched_examples=examples,seconds=time.time()-started)
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':run()
