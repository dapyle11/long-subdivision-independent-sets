#!/usr/bin/env python3
from fractions import Fraction
from check import *

def brute_poly(n,edges,ks):
    nn,es=expand(n,edges,ks);adj=[0]*nn
    for u,v in es:adj[u]|=1<<v;adj[v]|=1<<u
    coeff=[0]*(nn+1);full=(1<<nn)-1
    def rec(todo,dom,count):
        if not todo:
            if dom==full:coeff[count]+=1
            return
        bit=todo&-todo;v=bit.bit_length()-1;rest=todo^bit
        rec(rest,dom,count)
        rec(rest&~adj[v],dom|bit|adj[v],count+1)
    rec(full,0,0)
    return coeff

def weighted_kernel(k,z):
    t=((0,z,0),(0,0,1),(1,z,0));p=((1,0,0),(0,1,0),(0,0,1))
    for _ in range(k):p=matmul(p,t)
    first=(0,0,1);second=(0,1,0)
    return tuple(tuple(z**(second[a]-first[b])*p[a][REV[b]] for b in range(3)) for a in range(3))

def weighted_tensor(n,edges,ks,z):
    fs={}
    for k in set(ks):
        ker=weighted_kernel(k,z)
        fs[k]=tuple(tuple(sum(ker[i][j] for i in TYPES[a] for j in TYPES[b]) for b in range(3)) for a in range(3))
    ans=0
    for types in product(range(3),repeat=n):
        term=z**types.count(0)*((-1)**types.count(2))
        for (u,v),k in zip(edges,ks):term*=fs[k][types[u]][types[v]]
        ans+=term
    return ans

def run_weighted():
    total=0
    for n in range(5):
        for es in allgraphs(n):
            for k in range(3):
                ks=[k]*len(es);coeff=brute_poly(n,es,ks)
                for z in [Fraction(1,2),Fraction(2,1)]:
                    actual=sum(c*z**i for i,c in enumerate(coeff))
                    predicted=weighted_tensor(n,es,ks,z)
                    assert actual==predicted,(n,es,ks,z,actual,predicted)
                    total+=1
    spectral=[]
    for z in [0.5,1.0,2.0]:
        r=(z/2+sqrt(z*z/4-z*z*z/27))**(1/3)+(z/2-sqrt(z*z/4-z*z*z/27))**(1/3)
        a=complex(-r/2,sqrt(4*z/r-r*r)/2)
        maxerror=0.0
        for k in range(16):
            ker=weighted_kernel(k,z)
            wr=(1,r,r*r/z);wa=(1,a,a*a/z)
            for i in range(3):
                for j in range(3):
                    spec=r**k*wr[i]*wr[j]/(2*r+3)+2*(a**k*wa[i]*wa[j]/(2*a+3)).real
                    err=abs(ker[i][j]-spec)/max(1,abs(ker[i][j]));maxerror=max(maxerror,err)
                    assert err<1e-12,(z,k,i,j,ker[i][j],spec)
        spectral.append(dict(z=z,max_relative_error=maxerror))
    out=dict(exact_rational_weighted_cases=total,spectral_kernel_checks=spectral)
    (OUT/'weighted.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':run_weighted()
