#!/usr/bin/env python3
from check import *

def brute_law(n,edges,ks):
    nn,es=expand(n,edges,ks); adj=[0]*nn
    for u,v in es:adj[u]|=1<<v;adj[v]|=1<<u
    allmask=(1<<nn)-1; hist=[0]*(1<<n)
    def rec(todo,dominated,selected):
        if not todo:
            if dominated==allmask:hist[selected&((1<<n)-1)]+=1
            return
        vbit=todo&-todo;v=vbit.bit_length()-1; rest=todo^vbit
        rec(rest,dominated,selected)
        rec(rest&~adj[v],dominated|vbit|adj[v],selected|vbit)
    rec(allmask,0,0)
    return hist

def tensor_law(n,edges,ks):
    factors={}
    for k in set(ks):
        p=power(k);ker=tuple(tuple(p[i][REV[j]] for j in range(3)) for i in range(3))
        factors[k]=tuple(tuple(sum(ker[i][j] for i in TYPES[a] for j in TYPES[b]) for b in range(3)) for a in range(3))
    hist=[0]*(1<<n)
    for types in product(range(3),repeat=n):
        term=-1 if types.count(2)%2 else 1
        for (u,v),k in zip(edges,ks):term*=factors[k][types[u]][types[v]]
        mask=sum(1<<i for i,t in enumerate(types) if t==0)
        hist[mask]+=term
    return hist

def limiting_law(n,edges):
    ds=[0]*n
    for u,v in edges:ds[u]+=1;ds[v]+=1
    ps=[lam**(2*d)/(lam**(2*d)+lam**(3*d)-1) for d in ds]
    law=[]
    for mask in range(1<<n):
        p=1
        for v,q in enumerate(ps):p*=q if mask>>v&1 else 1-q
        law.append(p)
    return law

def run_law():
    checked=0
    for k in range(3):
        for n in range(5):
            for es in allgraphs(n):
                ks=[k]*len(es)
                a=brute_law(n,es,ks);b=tensor_law(n,es,ks)
                assert a==b,(n,es,k,a,b)
                q=limiting_law(n,es)
                leading=lead(n,es,ks)
                delta=(1+B*theta**k)**len(es)-1
                for w,prob in zip(a,q):
                    if prob==0:assert w==0
                    else:assert abs(w/(leading*prob)-1)<=delta+1e-10
                checked+=1
    A=[(0,1),(1,2),(0,3),(3,4),(0,5)]
    E=[(0,1),(1,2),(2,3),(0,4),(0,5)]
    result=[]
    for k in [0,1,2,5,10,20]:
        aa=tensor_law(6,A,[k]*5);bb=tensor_law(6,E,[k]*5)
        ca=sum(aa);cb=sum(bb); leading=lead(6,A,[k]*5)
        qa=limiting_law(6,A);qb=limiting_law(6,E)
        tva=sum(abs(x/ca-y) for x,y in zip(aa,qa))/2
        tvb=sum(abs(x/cb-y) for x,y in zip(bb,qb))/2
        delta=(1+B*theta**k)**5-1
        result.append(dict(k=k,A_count=ca,B_count=cb,ratio_A_to_B=ca/cb,leading=leading,
                           A_relative_error=ca/leading-1,B_relative_error=cb/leading-1,
                           A_law_TV=tva,B_law_TV=tvb,delta=delta,
                           TV_bound=min(1,delta/(1-delta)) if delta<1 else 1))
    out=dict(law_cases_checked=checked,tree_A_edges=A,tree_B_edges=E,
             degree_sequence=[3,2,2,1,1,1],connected_tree_examples=result)
    (OUT/'law_and_trees.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':run_law()
